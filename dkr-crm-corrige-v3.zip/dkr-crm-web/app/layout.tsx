import './globals.css';
import type { Metadata } from 'next';
export const metadata: Metadata = { title:'DKR CRM', description:'CRM de courtage DKR Assurances' };
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="fr"><body>{children}</body></html>}
