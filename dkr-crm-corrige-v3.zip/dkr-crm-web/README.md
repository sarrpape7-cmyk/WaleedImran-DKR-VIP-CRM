# DKR CRM

CRM métier pour DKR Assurances / D-Assur Courstage.

## Stack
- Next.js 15
- React 19
- Supabase
- PostgreSQL / RLS
- Netlify

## Configuration
Créer les variables d'environnement :
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`

## Build
```bash
npm install
npm run build
```

Le projet est configuré pour un build Netlify avec Node 22.
